<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <link rel="stylesheet" href="estilo/index.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
        <title> Sistema bancário</title>
    </head>

    <body>

       <section>
        <h2>Login</h2>
            <?php

                $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
                
               //echo var_dump($dados); Var dump que serve para testar se o array esta recebendo os dados.
            
            ?>
            <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
                <label for="cpf">Cpf</label>
                <input type="text" name="cpf" required autocomplete="off" class="input-form"><br>

                <label for="senha">Senha</label>
                <input type="password" name="senha" required autocomplete="off" class="input-form">

                <input type="submit" value="Entrar" class="botao">

                <p><a href="Cadastro.php">Não tem uma conta? Clique aqui</p>
            </form>

            <?php

                /*Na tela de login vamos iniciar uma sessão */
                session_start();

                /*Antes de criar  a sessão, vamos verificar se os campos do form
                foram preenchidos corretamente */
                if(!empty($dados['cpf']) && !empty($dados['senha'])){

                    /*Se os campos forem preenchidos, vamos instanciar um objeto
                    banco de dados */
                    include 'Dados.php';

                    $banco = new Dados();

                    /*Vamos criar uma variável local que ira receber o metodo de login
                    com as informações passadas pelo usuário */
                    $usuario = $banco->Login($dados);

                    /*Por ultimo, vamos verificar se a sessão possui
                    informações */
                    if($usuario){

                        /*Caso a sessão tenha informações vamos pegar o cpf do usuário e
                        atribuir como valor da sessão */
                        $_SESSION['cpf']  = $usuario['cpf'];

                        /*Por ultimo, vamos fazer a transição para o menu principal, onde
                        o usuário poderá utilizar as funcionalidades do sistema */
                        header('Location: MenuPrincipal.php');

                        exit;
                    }
                }
            
            ?>
       </section>
    </body>
</html>