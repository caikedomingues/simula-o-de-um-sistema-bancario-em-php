
/*Criação do banco de dados que irá conter informações
sobre as contas bancárias e os dados pessoais do cliente*/
create database bancophp;

use bancophp;
/*Criação da tabela cliente*/
create table cliente(

	nome varchar(30),
    cpf varchar(11) not null,
    email text,
    ano_nascimento varchar(4),
    foto text, /*Coluna que irá guardar o caminho da foto de perfil do usuário*/
    senha int not null,
	/*Chave primária da tabela cliente*/
    primary key(cpf)

)default charset utf8;

/*Criação da tabela conta*/
create table conta(
	
    numero_conta varchar (4),
    tipo enum ('CC', 'CP') not null,
    saldo float,
    dono varchar(11),
    /*Chave primaria da tabela conta*/
    primary key(numero_conta),
    /*Chave estrangeira da tabela conta, vamos usar
    essa chave para acessar os cpfs da tabela cliente*/
    foreign key(dono) references cliente(cpf)

)default charset utf8;


/*Teste de inserção de dados*/
insert into cliente(nome, cpf, email, ano_nascimento, senha) values('Caike', '9090', 'caike@gmail', '2003', '12345');

insert into conta(numero_conta, tipo, saldo, dono) values('4444', 'CC', '2000', '9090');

/*Vamos ter que modificar o tipo da coluna senha para que o password_hash
do php realize a criptografia corretamente.*/
alter table cliente modify column senha varchar(255);

/**Após o ajuste da coluna senha, vamos apagar todos os dados e cadastra-los
novamente*/
/*Antes de excluir os dados precisamos desabilitar o modo safe do
mysql que bloqueia a exclusão de dados em comando sem  o WHERE.*/
set sql_safe_updates = 0;
delete from conta;
delete from cliente;

/*Teste de soma de valores*/
update conta set saldo = saldo + 2 where dono = '0909';


/*Comando que ira descrever a tabela.*/
describe cliente;
describe conta;

select * from cliente;
select * from conta; 