
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <link rel="stylesheet" href="estilo/transferir.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
    </head>

    <header>
            <nav class="menu">
                    <input type="checkbox" class="menu-faketrigger">
                    <div class="menu-lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li><a href="MenuPrincipal.php">inicio</a></li>
                        <li><a href="Deposito.php">depositar</a></li>
                        <li><a href="Investimento.php">Investir</a></li>
                        <li><a href="Sacar.php">Sacar</a></li>
                        <li class="transferir"><a href="#">Transferência de valores</a></li>
                        <li><a href="AtualizarConta.php">Atualizar Dados da conta</li></a>
                        <li><a href="AtualizarCliente.php">Atualizar Dados Pessoais</li></a>
                        <li><a href="Sair.php">Sair</a></li>
                    </ul>
            </nav>
            <h1>Menu Principal</h1>
    </header>

    <section>

        <?php
        
            $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

            //echo var_dump($dados);
        ?>

        <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
            <label for="valor">valor da transferência</label><br>
            <input type="number" name="valor" step="0.005" required class="input-form"><br>

            <label for="conta">Conta que ira receber o valor</label><br>
            <input type="text" name="conta" required class="input-form" autocomplete="off"><br>

            <input type="submit" value="Transferir valor" class="botao">
        </form>

        <?php
        
            if(!empty($dados)){

                include 'Dados.php';

                $transferencia = new Dados();

                $transferencia->Transferir($dados);
            }
        ?>
    </section>
</html>