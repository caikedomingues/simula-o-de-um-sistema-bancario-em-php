

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initila-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <title>Sistema Bancário</title>
        <link rel="stylesheet"href="estilo/deposito.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
    </head>

    <header>
             <nav class="menu">
                    <input type="checkbox" class="menu-faketrigger">
                    <div class="menu-lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li><a href="MenuPrincipal.php">inicio</a></li>
                        <li class="deposito"><a href="#">depositar</a></li>
                        <li><a href="Investimento.php">Investir</a></li>
                        <li><a href="Sacar.php">Sacar</a></li>
                        <li><a href="Transferir.php">Transferência de valores</a></li>
                        <li><a href="AtualizarConta.php">Atualizar Dados da conta</li></a>
                        <li><a href="AtualizarCliente.php">Atualizar Dados Pessoais</li></a>
                        <li><a href="Sair.php">Sair</a></li>
                    </ul>
            </nav>
            <h1>Menu Principal</h1>
       </header>

       <section>
            <?php
                /*captura do valor do depósito */
                $valor = filter_input_array(INPUT_POST, FILTER_DEFAULT);
            ?>
            
            <!--formulário que faz referencia a própria página-->
            <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
                <label for="valor">Informe o valor do deposito</label>
                <input type="number" step="0.005" name="valor" required class="input-form"><br>

                <input type="submit" Value="Depositar" class="botao">
            </form>

            <?php
                
                /*Antes de realizar a instancia e a chamada dos metodos,
                vamos verificar se o form esta com os  campos preenchidos*/
                if(!empty($valor)){

                    include 'Dados.php';

                    $deposito = new Dados();

                    $deposito->Depositar($valor);
                }
            
            
            ?>
       </section>
</html>