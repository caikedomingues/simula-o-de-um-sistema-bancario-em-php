


<?php
    /*Nessa parte, vamos criar o logout para o usuário sair de sua conta e encerrar
    a sua sessão */

    /*Primeiro vamos criar a sessão */
    session_start();

    /*Depois, vamos atribuir a sessão em uma variável local */
    $cpf = $_SESSION['cpf'];

    /*Antes de sair e encerrar a sessão, vamos verificar se há uma
    sessão iniciada. */
    if(isset($cpf)){

        /*Vamos apresentar uma mensagem informando ao usuário sobre a sua saida */
         echo "<script>alert('Você saiu do sistema, obrigado por utilizar');window.location.href = 'index.php';</script>";

         /*Vamos encerrar a sessão */
        session_abort();

        exit; //evita a execução de código adicional que possa interferir no fluxo do seu aplicativo.

    }else{

        echo "<script>alert('Erro ao sair do sistema')</script>";
    }

?>