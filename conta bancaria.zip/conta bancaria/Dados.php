


<?php

    class Dados{

        /*Metodo que ira se conectar ao banco de dados */
        private function conexao(){

            try{
                
                /*Variável que ira conter a instancia do PDO que recebe como parametro o endereço do banco
                de dados, o usuário e a senha. */
                $conexao = new PDO('mysql:host=localhost;port=3306;dbname=bancophp','root','');

                /*Retorno do metodo */
                return $conexao;
    
            }catch(PDOException $erro){
                
                /*Exception que será lançada caso o sistema não consiga se conectar com
                o banco de dados. */
                echo "<scrip>alert('Erro ao se conectar com o banco de dados: ' $erro)</script>";
            }
        }


        /*metodo que ira cadastrar usuários no banco de dados, o metodo ira receber 3 parametros
        do tipo array.
        Dados_cliente: referente ao array de dados do cliente.
        Dados_conta: referente ao array de dados da conta. 
        fotos: referente a superglobal $_FILES que ira conter os dados
        da foto escolhida pelo usuário*/
        public function cadastro(array $dados_cliente, array $dados_conta, array $fotos){

            /*Chamada do metodo de conexão com o banco de dados. */
            $conexao = $this->conexao();
            /*Variáveis que irão percorrer o banco de dados em busca do cpf e do numero da conta (ambos são chaves
            primarias de suas tabelas) para verificar se esses registros existem. */
            $Selecao_cliente = $conexao->query("SELECT * FROM cliente WHERE cpf='".$dados_cliente['cpf']."'");

            $selecao_conta = $conexao->query("SELECT * FROM conta WHERE numero_conta='".$dados_conta['numero_conta']."'");

            /*Essas variáveis irão conter a quantidade de linhas encontradas
            no select das 2 tabelas */
            $quantidade_linhas_cliente = $Selecao_cliente->rowCount();

            $quantidade_linhas_conta = $selecao_conta->rowCount();

            /*Se a quantidade de contas ou clientes for maior que 0, vamos
            informar ao usuário que o registro ja existe e não será cadastrado
            novamente */
            if($quantidade_linhas_cliente > 0 || $quantidade_linhas_conta > 0){

                echo "<script>alert('esses dados ja existem no sistema, por favor, informe novos dados')</script>";

            }else{

                /*Instancia dos objetos */

                require_once "Cliente.php";
                require_once "Conta.php";

                $cliente = new Cliente();

                $conta = new Conta();
                
                /*Chamada dos metodos setters que receberão como parametro
                os arrays e seus indices */
                $cliente->setNome($dados_cliente['nome']);
                $cliente->setCpf($dados_cliente['cpf']);
                $cliente->setAnoNascimento($dados_cliente['ano_nascimento']);
                $cliente->setEmail($dados_cliente['email']);
                $cliente->setSenha($dados_cliente['senha']);
                
                /*Metodos getters que conterão os valores dos metodos setters */
                $nome_cliente = $cliente->getNome();

                $cpf_cliente = $cliente->getCpf();

                $ano_nascimento_cliente = $cliente->getAnoNascimento();

                $email_cliente = trim($cliente->getEmail()); /*O email_cliente ira receber
                o metodo trim que ira limpar os espaços em branco o que  facilitara e possibilitara
                verificar se o email é valido
                 */

                 /*A  variável email_cliente ira receber o metodo password_hash que 
                 ira criptografar a senha do usuário */
                $senha_cliente = password_hash($cliente->getSenha(), PASSWORD_DEFAULT);

                /*a variável fotos_cliente ira receber o caminho da pasta que irá 
                conter as fotos */
                $fotos_cliente = "imagens/".$fotos['name'];

                /*Metodo que ira mover os arquivos da pasta temporari do servidor 
                para a pasta do projeto */
                move_uploaded_file($fotos["tmp_name"], $fotos_cliente);

                /*Setter da classe Conta */
                $conta->setNumero($dados_conta['numero_conta']);
                $conta->setTipo($dados_conta['tipo']);
                $conta->setSaldo($dados_conta['saldo']);

                /*Getters que conterão os valores da classe conta */
                $numero_conta = $conta->getNumero();
                $tipo_conta = strtoupper($conta->getTipo()); //O metodo strtoupper ira transformar letras minusculas em maiusculas
                $saldo_conta = $conta->getSaldo();

                                        /*VALIDAÇÕES */
                
                /*Primeiro, vamos verificar se a quantidade de caracteres
                do cpf é maior que 11 */
                if(strlen($cpf_cliente) > 11){

                    /*Se a condição for verdadeira, vamos informar o usuário que a quantidade
                    não é aceitavel e encerraremos a execução do metodo */
                    echo "<script> alert('O cpf deve conter 11 digitos ou menos')</script>";

                    die;
                }

                /*Nessa etapa, vamos verificar se o usuário possui idade suficiente para abrir
                uma conta bancária */
                /*Primeiro, vamos configurar o fuso horario do sistema para a nossa região */
                date_default_timezone_set('America/Sao_Paulo');
                /*Vamos puxar o ano do sistema */
                $ano_sistema = date('Y');

                /*Cálculo da idade do usuário */
                $calc_idade_usuario = $ano_sistema - $ano_nascimento_cliente; 

                /*Verificação da idade */
                if($calc_idade_usuario < 18){

                    /*Impressão da mensagem de falha na inserção por conta da idade */
                    echo "<script>alert('este usuário não pode abrir uma conta, pois é um menor de idade')</script>";

                    /*Interrupção do código */
                    die;
                }


                /*Depois iremos verificar a quantidade de caracteres do numero da conta */
                if(strlen($numero_conta) > 4){

                    /*Se a condição for verdadeira, vamos informar o usuário que a quantidade
                    não é aceitavel e encerraremos a execução do metodo */ 
                    echo "<script> alert('O numero da conta deve conter 4 digitos ou menos')</script>";

                    die;

                }
                
                /*Na parte dos tipos de conta, iremos verificar se o valor informado
                é diferente da sigla "CC" ou "CP" */
                if($tipo_conta != "CC" && $tipo_conta!= "CP"){

                    /*Se a condição for verdadeira, vamos informar o usuário e encerrar a execução */
                    echo "<script>alert('Por favor digite apenas CC ou CP')</script>";

                    die;

                }

                /*Por ultimo vamos verificar se o endereço do email possui um @. */
                if(!str_contains($email_cliente, "@")){

                    /*Caso a afirmação seja verdadeira, iremos informar o usuário e enecerrar a execução
                    do metodo */
                    echo "<script>alert('Por favor digite um email válido utilizando o @ no endereço')</script>";

                    die;
                }

                /*Após todas as verificações, vamos inserir os dados no banco mysql */
                $insercao_cliente = $conexao->query("INSERT INTO cliente(nome, cpf, ano_nascimento, email, senha,foto ) VALUES('".$nome_cliente."', '".$cpf_cliente."', '".$ano_nascimento_cliente."','".$email_cliente."', '".$senha_cliente."', '".$fotos_cliente."')");

                $insercao_conta = $conexao->query("INSERT INTO conta(numero_conta, tipo, saldo, dono) VALUES('".$numero_conta."', '".$tipo_conta."', '".$saldo_conta."', '".$cpf_cliente."')");

                
                /*Após inserir os dados vamos verificar se a conta é do tipo. se a condição for verdadeira 
                vamos adicionar 50 reais em seu saldo, como um valor inicial que o cliente podera sacar ou investir*/

                if($tipo_conta == "CP"){

                    $adicionar_50 = $conexao->query("UPDATE conta set saldo = '".$saldo_conta."' + 50 WHERE dono='".$cpf_cliente."'");

                    echo "<script> alert('Você ganhou 50 reais para realizar seu primeiro saque ou investimento')</script>";
                }


                echo "<script>alert('Dados cadastrados com sucesso')</script>";
                
            

            }

        }

        /*Metodos que ira verificar se o usuário existe no banco de dados*/
        public function Login(array $dados){
            /*Chamada da conexão */
            $conexao = $this->conexao();

            /*Consulta no banco de dados que ira buscar o cpf informado pelo usuário */
            $selecao_sql = $conexao->query("SELECT * FROM cliente WHERE cpf='".$dados['cpf']."'");

            /*Ira contar a quantidade de linhas encontradas */
            $quantidade_linhas = $selecao_sql->rowCount();

            /*Se o cpf for encontrado vamos verificar a senha informada */
            if($quantidade_linhas > 0){

                /*Para dar inicio na verificação da senha vamos transformar
                as colunas do banco em arrays associativos, dessa maneira,
                conseguiremos acessar os indices através do nome da coluna. */
                $colunas = $selecao_sql->fetch(PDO::FETCH_ASSOC);

                /*Na segunda etapa, vamos verificar a senha informada usando 
                o metodo password_verify que descriptografa senhas */
                if(password_verify($dados['senha'], $colunas['senha'])){

                    /*Se a senha estiver correta, vamos dar um return nos dados para
                    podermos utilizar os valores na criação de sessões*/
                    return $dados;

                }else{

                    /*Se o usuário não for encontrado o sistema apresentara uma mensagem. */
                    echo "<script>alert('Usuário não encontrado')</script>";
                    
                }
            }
        }

        /*metodo que ira imprimir as informações do usuário
        após o login */
        public function FichaTecnica(){
            /*Ao realizar o login vamos iniciar uma sessão */
            session_start();
            /*Chamada do metodo de conexão */
            $conexao = $this->conexao();

            /*Atribuição da sessão que contem o cpf a uma variável local */
            $cpf = $_SESSION['cpf'];

            /*Seleção dos dados da conta */
            $consulta_conta = $conexao->query("SELECT numero_conta, tipo, saldo, dono FROM conta WHERE dono='".$cpf."'");
            /*Seleção dos dados do cliente */
            $consulta_cliente = $conexao->query("SELECT email, foto FROM cliente WHERE cpf='".$cpf."'");

            /*Transformando as colunas da conta em arrays associativos */
            $resultado_conta = $consulta_conta->fetch(PDO::FETCH_ASSOC);

            /*Transformando  as colunas do cliente em arrays associativos*/
            $resultado_cliente = $consulta_cliente->fetch(PDO::FETCH_ASSOC);

            /*Impressão dos valores na ficha */
           echo "<p> Numero da conta: ".$resultado_conta['numero_conta']."</p>";

           echo "<p> tipo: ".$resultado_conta['tipo']."</p>";

           echo "<p> saldo atual: ".$resultado_conta['saldo']."</p>";

           echo "<p> cpf do dono da conta: ".$resultado_conta['dono'];

           echo "<p>Email: ".$resultado_cliente['email']."</p>";

           echo "<p>foto de perfil</p>";

           echo  "<img src='".$resultado_cliente['foto']."' alt='foto de perfil' class='imagem-perfil'>";



        
        }

        /*Metodo que ira possibilitar o deposito do usuário em sua conta */
        public function Depositar(array $valor){

            /*Inicio da sessão */
            session_start();

            /*Chamada da conexao com o banco de dados */
            $conexao = $this->conexao();

            /*Atribuição da sessão em uma variável local */
            $cpf = $_SESSION['cpf'];

            /*Antes de realizar as operações, vamos verificar se a sessão foi
            iniciada */
            if(isset($cpf)){

                /*Mensagem que ira sinalizar que o deposito foi efetuado com sucesso */
                echo "<script>alert('deposito no valor de {$valor['valor']} efetuado')</script>";

                /*Comando que ira somar o valor do depósito no saldo atual do usuário */
                $deposito = $conexao->query("UPDATE conta set saldo = saldo + '".$valor['valor']."' WHERE dono='".$cpf."'");

            }else{
                /*Se o deposito falhar, vamos imprimir uma mensagem para o usuário */
                echo "<script>alert('Erro no sistema, não foi possivel realizar o depósito, tente novamente mais tarde')</script>";
            }
        }

        /*Metodo responsável por realizar os investimento dos usuários */
        public function Investir(array $valor){

            /*Antes de tudo, vamos iniciar a sessão do usuário */
            session_start();
            /*Vamos atribuir a sessão em uma variável local */
            $cpf = $_SESSION['cpf'];

            /*Chamada da conexão */
            $conexao= $this->conexao();

            /*Gerador de valores aleatórios entre 0 e 100 */
            $resultado_investimento = rand(0,100);

            /*Antes de iniciar o processo de investimento, vamos verificar
            se a sessão foi iniciada */
            if(isset($cpf)){

                /*Se tudo estiver correto, vamos selecionar o saldo atual do cliente */
                $selecao_saldo = $conexao->query("SELECT saldo FROM conta WHERE dono='".$cpf."'");
                /*Vamos tranformar a coluna do saldo em um array associativo */
                $valor_saldo = $selecao_saldo->fetch(PDO::FETCH_ASSOC);

                /*Antes de iniciar o investimento, vamos verificar se o saldo possui
                o valor que o usuário quer investir */
                if($valor['valor'] <= $valor_saldo['saldo']){

                    /*Se o saldo for suficiente, vamos debitar o valor investido*/
                    $invesimento = $conexao->query("UPDATE conta set saldo = saldo - '".$valor['valor']."' WHERE dono='".$cpf."'");

                    /*Depois vamos depositar o valor do investimento na conta do usuário */
                    $valor_ganho = $conexao->query("UPDATE conta set saldo = saldo + '".$resultado_investimento."' WHERE dono='".$cpf."'");

                    /*Se o retorno do investimento for maior que o valor investido,
                    vamos informar ao usuário que o ROI foi positivo */
                   if($resultado_investimento > $valor['valor']){

                        echo "<script>alert('Valor investido: {$valor['valor']}')</script>";

                        echo "<script>alert('Valor arrecado com o investimento: {$resultado_investimento}')</script>";

                        echo "<script>alert('ROI: POSITIVO')</script>";

                   }else{

                      /*Caso contrário, vamos informar ao usuário que o ROI foi negativo */
                       echo "<script>alert('Valor investido: {$valor['valor']}')</script>";

                       echo "<script>alert('Valor arrecado com o investimento: {$resultado_investimento}')</script>";

                       echo "<script>alert('ROI: NEGATIVO')</script>"; 
                   }

                }else{

                    /*Mensagem que será exibida caso o saldo para investimento seja insuficiente */
                    echo "<script>alert('Saldo insuficiente para investimento')</script>";
                }

            }else{  

                /*Caso a sessão não seja inicializada, vamos informar ao usuário sobre o erro do sistema */
                echo "<script>alert('Erro no sistema, não foi possivel realizar o investimento, tente novamente mais tarde')</script>";
            }
        }

        /*Metodo que ira possibilitar que o usuário realize saques */
        public function Saque(array $valor){

            /*Inicio da sessão */
            session_start();

            /*Atribuindo a sessão em uma variável local */
            $cpf = $_SESSION['cpf'];

            /*Chamada da conexão */
            $conexao = $this->conexao();

            /*Antes de iniciar o processo de saque, vamos verificar se a sessão 
            foi inicializada */
            if(isset($cpf)){

                /*Primeiro vamos consultar o saldo do usuário */
                $selecao_saldo = $conexao->query("SELECT saldo FROM conta WHERE dono='".$cpf."'");

                /*Depois, vamos transformar a coluna em um array associativo */
                $coluna_saldo = $selecao_saldo->fetch(PDO::FETCH_ASSOC);

                /*Antes de realizar o saque, vamos verificar se o saldo do usuário é 
                suficiente para efetuar o saque */
                if($valor['valor'] <= $coluna_saldo['saldo']){

                    /*Se o valor for suficiente, vamos informar ao usuário que o saque foi 
                    realizado com sucesso */
                    echo "<script>alert('saque no valor de {$valor['valor']} reais realizado com sucesso')</script>";

                    /*vamos debitar o valor do saque da conta do cliente */
                    $saque = $conexao->query("UPDATE conta set saldo = saldo - '".$valor['valor']."' WHERE dono='".$cpf."'");

                    /*Para imprimir a mensagem de saldo atual, vamos novamente selecionar
                    o valor do saldo para pegar o saldo atual do cliente*/
                    $novo_saldo = $conexao->query("SELECT saldo FROM conta WHERE dono='".$cpf."'");

                    /*Vamos transformar novamente a coluna em um array associativo */
                    $nova_coluna_saldo = $novo_saldo->fetch(PDO::FETCH_ASSOC); 

                    /*Impressão do saldo atual do cliente */
                    echo "<script>alert('saldo atual: {$nova_coluna_saldo['saldo']}')</script>";


                }else{

                    /*Caso o saldo seja insuficiente, vamos informar ao usuário que 
                    o saque não foi realizado e apresentar o saldo atual para saque */
                    echo "<script>alert('saldo insuficiente para saque')</script>";
                    echo "<script>alert('saldo atual: {$coluna_saldo['saldo']}')</script>";
                }

            }else{

                /*Caso a sessão não seja inicializada, vamos informar o usuário sobre a 
                falha no sistema. */
                echo "<script>alert('erro no sistema, tente novamente mais tarde')</script>";
            }
        }

        /*Metodo que ira realizar a transferencia de valores entre as contas */
        public function Transferir(array $dados){
            
            /*Inicio da sessão */
            session_start();

            /*Atribuição da sessão em uma variável local */
            $cpf = $_SESSION['cpf'];

            /*Chamada da conexao com o banco de dados */
            $conexao = $this->conexao();

            /*Antes de iniciar o processo de transferencia, vamos verificar se a sessão foi iniciada */
            if(isset($cpf)){

                /*SE a sessão for inicializada, vamos buscar as informações da conta que ira receber o valor
                da transferencia */
                $selecao_conta_destinatario = $conexao->query("SELECT * FROM conta WHERE numero_conta='".$dados['conta']."'");
                /*Vamos contar a quantidade de linhas encontradas durante a seleção */
                $quantidade_linhas_conta_destinatario = $selecao_conta_destinatario->rowCount();

                /*Agora vamos verificar se a conta que ira receber o valor de fato existe 
                no banco de dados.*/
                if($quantidade_linhas_conta_destinatario > 0){

                    /*Se a conta existir no banco de dados, vamos dar inicio a seleção dos dados
                    da conta que ira enviar o valor da transferencia. */
                    $selecao_conta_remetente = $conexao->query("SELECT * FROM conta WHERE dono='".$cpf."'");
                    
                    /*Vamos transformar as colunas em um array associativo para poder verficar
                    o saldo da conta remetente. */
                    $coluna_conta_remetente = $selecao_conta_remetente->fetch(PDO::FETCH_ASSOC);

                    /*Se o valor do saldo for menor ou igual ao saldo do cliente remetente,
                    vamos iniciar o processo de transferencia. */
                    if($dados['valor'] <= $coluna_conta_remetente['saldo']){

                        /*Mensagem que indica que a transição foi realizada com sucesso. */
                        echo "<script>alert('Transação realizada com sucesso')</script>";

                        /*Processo que ira debitar o valor da transferencia do saldo da conta remetente */
                        $transferencia = $conexao->query("UPDATE conta SET saldo = saldo - '".$dados['valor']."' WHERE dono='".$cpf."'");

                        /*Processo de deposito no saldo da conta destinataria */
                        $destino = $conexao->query("UPDATE conta SET saldo = saldo + '".$dados['valor']."' WHERE numero_conta = '".$dados['conta']."'");

                        /*Chamada do metodo de comprovante */
                        $comprovante = $this->comprovante($dados);
                    
                    }else{  

                        /*Caso o saldo seja insuficiente para a transferencia, vamos informar o usuário
                        da situação */
                        echo "<script>alert('Saldo insuficiente para transferencia')</script>";
                    }

                }else{

                    /*Caso a conta informada não exista no banco de dados. */
                    echo "<script>alert('Conta não encontrada no sistema')</script>";

                }

            }else{
                
                /*Caso há problemas na inicialização da sessão. */
                echo "<script>alert('erro no sistema, tente novamente mais tarde')</script>";
            }
        }


        /*Metodo que ira imprimir as informações do comprovante */
        private function comprovante(array $dados_comprovante){

           /*chamada do metodo de conexao com o banco de dados */ 
            $conexao = $this->conexao();

            /*atribuição da sessão em uma variável local */
            $cpf = $_SESSION['cpf'];

            /*Seleções do destinatario */

            /*Antes de tudo, vamos selecionar o numero da conta que ira receber a transferencia */
            $selecao_conta_destinatario = $conexao->query("SELECT * FROM conta WHERE numero_conta='".$dados_comprovante['conta']."'");

            /*Transformando a seleção da conta em um array associativo */
            $coluna_conta_destinatario = $selecao_conta_destinatario->fetch(PDO::FETCH_ASSOC);  

            /*Agora, vamos selecionar os dados do cliente que ira receber os valores */
            $selecao_cliente_destinatario = $conexao->query("SELECT * FROM cliente WHERE cpf='".$coluna_conta_destinatario['dono']."'");

            /*Transformando os dados do cliente em um array associativo */
            $coluna_cliente_destinatario = $selecao_cliente_destinatario->fetch(PDO::FETCH_ASSOC);

            /*Seleções do remetente */
            /*Seleção dos dados da conta que ira enviar o valor para o destinatário*/
            $selecao_conta_remetente = $conexao->query("SELECT * FROM conta WHERE dono='".$cpf."'");

            /*transformando os dados da conta em um array associativo */
            $coluna_conta_remetente = $selecao_conta_remetente->fetch(PDO::FETCH_ASSOC);

            /*Seleção dos dados do cliente que ira enviar o valor para o destinatário */
            $selecao_cliente_remetente = $conexao->query("SELECT * FROM cliente WHERE cpf='".$cpf."'");

            /*Transformando os dados do cliente em um array associativo */
            $coluna_cliente_remetente = $selecao_cliente_remetente->fetch(PDO::FETCH_ASSOC);

            /*Na parte das datas e das horas,vamos configurar o fuso horário para
            o padrão do brasil */
            date_default_timezone_set('America/Sao_Paulo');

            /*Vamos pegar a data e a hora exata do sistema */
            $data_e_hora = date('d-m-Y:H:i');

           /*Impressão do comprovante */
            echo "<h2>dados de quem pagou</h2>";
            echo "<p>nome: ".$coluna_cliente_remetente['nome']."</p>";
            echo "<p>cpf: ".$coluna_cliente_remetente['cpf']."</p>";
            echo "<p>Instituição: Sistema Bancário</p>";
            echo "<h2>Dados da transação</h2>";
            echo "<P> valor: ".$dados_comprovante['valor']."</p>";
            echo "<p>Data e hora: ".$data_e_hora."</p>";
            echo "<p>Tipo da conta debitada: ".$coluna_conta_remetente['tipo']."</p>";
            echo "<h2>Dados de quem recebeu</h2>";
            echo "<p>nome: ".$coluna_cliente_destinatario['nome']."</p>";
            echo "<p>cpf: ".$coluna_cliente_destinatario['cpf']."</p>";
            echo "<p>Instituição: Sistema Bancário<p>";
        }


            /* metodo que ira atualizar os dados da conta do cliente*/
            public function atualizarConta(array $dados_conta){
                /*Inicio da sessão */
                session_start();
                /*Atribuindo a sessão em uma variável local */
                $cpf = $_SESSION['cpf'];

                /*Chamada do metodo que se conecta ao banco de dados */
                $conexao = $this->conexao();

                /*Antes de iniciar o processo de atualização, vamos
                verificar se a sessão foi iniciada*/
                if(isset($cpf)){

                    /*Include da classe que será utilizada */
                    require_once 'Conta.php';

                    /*Instancia do objeto */
                    $conta = new Conta();

                    /*Metodos setters */
                    $conta->setNumero($dados_conta['numero_conta']);

                    $conta->setTipo($dados_conta['tipo']);

                    $conta->setSaldo($dados_conta['saldo']);

                    /*Metodos getters */
                    $numero_conta = $conta->getNumero();

                    $tipo_conta = strtoupper($conta->getTipo());/*Nessa parte, vamos transformar todas as strings do campo
                    em maiusculas */

                    $saldo_conta = $conta->getSaldo();

                    /*Vamos verificar se o numero da conta ja existe no sistema */
                    $selecao_conta = $conexao->query("SELECT numero_conta FROM conta WHERE numero_conta='".$numero_conta."'");

                    /*Vamos contar a quantidade de linhas encontradas */
                    $quantidade_linhas_conta = $selecao_conta->rowCount();

                    if($quantidade_linhas_conta > 0){

                        /*Caso o numero da conta ja exista, vamos informar o usuário e encerrar
                        a atualização */
                        echo "<script>alert('Essa conta ja existe no sistema')</script>";
                       
                    }else{

                        /*Caso a conta não exista vamos iniciar as validações para garantir que
                        a atualização seja feita da maneira correta. */

                        /*primeiro vamos verificar se o numero da conta possui 4
                        digitos */
                        if(strlen($numero_conta) > 4){

                            echo "<script>alert('O numero da conta deve conter no máximo 4 digitos')</script>";
                            /*Encerra a execução do metodo evitando a atualização por conta do erro */
                            die;
                        }

                        /*Ira verificar se o tipo da conta é CC ou CP */
                        if($tipo_conta != "CC" && $tipo_conta != "CP"){

                            echo "<script>alert('Por favor digite apenas CC ou CP')</script>";

                             /*Encerra a execução do metodo evitando a atualização por conta do erro */
                            die;
                        }

                        /*Atualizações do dados da conta */
                        echo "<script>alert('dados atualizados com sucesso')</script>";

                        $atualizar_numero_conta = $conexao->query("UPDATE conta SET numero_conta = '".$numero_conta."' WHERE dono='".$cpf."'");

                        $atualizar_tipo = $conexao->query("UPDATE conta SET tipo='".$tipo_conta."' WHERE dono='".$cpf."'");

                        $atualizar_saldo = $conexao->query("UPDATE conta SET saldo = '".$saldo_conta."' WHERE dono='".$cpf."'");
                        
                        
                        /*Se a conta for do tipo CP vamos adicionar 50 reais na conta so usuário */
                        if($tipo_conta == "CP"){

                            echo "<script>alert('você ganhou 50 reais para investir ou sacar')</script>";
                            $adicionar_50 = $conexao->query("UPDATE conta SET saldo='".$saldo_conta."' + 50 WHERE dono='".$cpf."'");
                        }


                    }

                }else{

                    /*Caso a sessão não seja inicializada, vamos informar o usuário da falha no sistema */
                    echo "<script>alert('Erro no sistema, tente novamente mais tarde')</script>";
                }

            }


            public function atualizarCliente(array $dados, array $fotos){

                session_start();

                $cpf = $_SESSION['cpf'];

                $conexao = $this->conexao();

                if(isset($cpf)){

                    require_once 'Cliente.php';

                    $cliente = new Cliente();

                    /*Metodos setters */

                    $cliente->setNome($dados['nome']);

                    $cliente->setEmail($dados['email']);

                    $cliente->setAnoNascimento($dados['ano_nascimento']);

                    $cliente->setSenha($dados['senha']);

                    /*Metodos Getters */

                    $nome = $cliente->getNome();

                    $email = trim($cliente->getEmail());/*Vamos remover os espaços para facilitar a verificação do email */

                    $ano_nascimento = $cliente->getAnoNascimento();

                    $destino_fotos = "imagens/".$fotos['name'];/*Caminho da pasta de fotos de perfil */

                    /*Metodo que ira mover o caminho da imagem da pasta temporaria para
                    a pasta de fotos de perfil */
                    move_uploaded_file($fotos["tmp_name"], $destino_fotos);

                    /*Criptografia da senha armazenada pelo usuário */
                    $senha = password_hash($cliente->getSenha(), PASSWORD_DEFAULT);

                    /*Vamos verificar se o usuário é um menor de idade */
                    date_default_timezone_set('America/Sao_Paulo');

                    /*Vamos pegar o ano do sistema */
                    $ano_sistema = date('Y');

                    /**Cálculo da idade */
                    $calc_idade = $ano_sistema - $ano_nascimento;

                    /*Vamos verificar se a idade do usuário */
                    if($calc_idade < 18){

                        /*se for um menor de idade, vamos encerrar o metodo e interromper a atualização. */
                        echo "<script>alert('Esse usuário não pode ter uma conta, pois, é um menor de idade')</script>";

                        die;
                    }

                    if(!str_contains($email, "@")){

                        echo "<script>alert('Por favor digite um email válido utilizando o @')</script>";

                        die;
                    }

                    /*Atualização dos dados*/
                    echo "<script>alert('Dados pessoais atualizados')</script>";
                    $atualizar_nome = $conexao->query("UPDATE cliente SET nome='".$nome."' WHERE cpf='".$cpf."'");

                    $atualizar_email = $conexao->query("UPDATE cliente SET email='".$email."' WHERE cpf='".$cpf."'");

                    $atualizar_ano_nascimento = $conexao->query("UPDATE cliente SET ano_nascimento = '".$ano_nascimento."' WHERE cpf='".$cpf."'");

                    $atualizar_foto = $conexao->query("UPDATE cliente SET foto = '".$destino_fotos."' WHERE cpf='".$cpf."'");

                    $atualizar_senha = $conexao->query("UPDATE cliente SET senha = '".$senha."' WHERE cpf='".$cpf."'");
                }
            }
         }
        



       
        
    

    

?>
