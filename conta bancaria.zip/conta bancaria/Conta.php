

<?php


    require_once "Cliente.php";

    class Conta{

        private string $numero;
        private string $tipo;
        private float $saldo;


        /*Getter e setters */

        public function setNumero(string $numero){

            $this->numero = $numero;

        }

        public function getNumero(){

            return $this->numero;
        }

        public function setTipo(string $tipo){

            $this->tipo = $tipo;
        }

        public function getTipo(){

            return $this->tipo;
        }

        public function setSaldo(float $saldo){

            $this->saldo = $saldo;
        }

        public function getSaldo(){

            return $this->saldo;
        }
    }


?>