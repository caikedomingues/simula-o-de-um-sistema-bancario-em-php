<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <link rel="shotcuts icon" href = "imagens/logo.jpg">
        <link rel="stylesheet" href="estilo/AtualizarConta.css">
    </head>

    <body>
         <header>
             <nav class="menu">
                    <input type="checkbox" class="menu-faketrigger">
                    <div class="menu-lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li><a href="MenuPrincipal.php">inicio</a></li>
                        <li><a href="Deposito.php">depositar</a></li>
                        <li><a href="Investimento.php">Investir</a></li>
                        <li><a href="Sacar.php">Sacar</a></li>
                        <li><a href="Transferir.php">Transferência de valores</a></li>
                        <li class="atualizar_conta"><a href="#">Atualizar Dados da conta</li></a>
                        <li><a href="AtualizarCliente.php">Atualizar Dados Pessoais</li></a>
                        <li><a href="Sair.php">Sair</a></li>
                    </ul>
            </nav>
            <h1>Menu Principal</h1>
          </header>

          <section>
            <?php
                /*Captura dos dados */

                $dados_conta = filter_input_array(INPUT_POST, FILTER_DEFAULT);
            ?>

            <form action="<?php $_SERVER['PHP_SELF']?>" method="post"  enctype="multipart/form-data">


                <label for="numero_conta">Novo numero de conta</label><br>
                <input type="text" name="numero_conta" class="input-form" required autocomplete="off"><br>

                <label for="tipo">Novo tipo da conta(CC ou CP)</label><br>
                <input type="text" name="tipo" required class="input-form" autocomplete="off"><br>

                <label for="saldo">Novo saldo</label><br>
                <input type="number" step="0.005" name="saldo" class="input-form" required autocomplete="off"> 

                <input type="submit" value="Atualizar Dados" class="botao">
            </form>

            <?php

                echo "<script>alert('Por favor, para atualização de cpfs entre em contato com 
                o desenvolvedor')</script>";
            
                if(!empty($dados_conta)){

                    include 'Dados.php';

                    $atualizar = new Dados();

                    $atualizar->atualizarConta($dados_conta);


                }
            ?>

          </section>
    </body>
</html>