

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <link rel="stylesheet" href="estilo/investimento.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
        <title>Sistema Bancário</title>
    </head>

    <header>
            <nav class="menu">
                    <input type="checkbox" class="menu-faketrigger">
                    <div class="menu-lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li><a href="MenuPrincipal.php">inicio</a></li>
                        <li><a href="Deposito.php">depositar</a></li>
                        <li class="investimento"><a href="#">Investir</a></li>
                        <li><a href="Sacar.php">Sacar</a></li>
                        <li><a href="Transferir.php">Transferência de valores</a></li>
                        <li><a href="AtualizarConta.php">Atualizar Dados da conta</li></a>
                        <li><a href="AtualizarCliente.php">Atualizar Dados Pessoais</li></a>
                        <li><a href="Sair.php">Sair</a></li>
                    </ul>
            </nav>
            <h1>Menu Principal</h1>
    </header>

    <section>
        <?php
        
            $valor = filter_input_array(INPUT_POST, FILTER_DEFAULT);
        ?>
        <p><strong>Regras do investimento:</strong> Deposite um valor da sua conta e receba
        o valor gerado pelo gerador de numeros aleatórios.</p>

        <p><strong>Observação:</strong>O gerador ira gerar numeros entre 0 e 100</p>

        <p class="ultima-linha">pretendo melhorar essa parte futuramente.</p>

        <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
            <label for="valor">Valor do investimento</label><br>
            <input type="number" step="0.0005" name="valor" class="input-form" required><br>
            <input type="submit" value="Investir" class="botao">
        </form>

        <?php
        
            if(!empty($valor)){

                include 'Dados.php';

                $investimento = new Dados();

                $investimento->Investir($valor);
            }
        ?>
    </section>
</html>