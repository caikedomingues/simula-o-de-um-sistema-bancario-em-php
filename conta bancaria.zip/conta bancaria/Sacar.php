

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <link rel="stylesheet" href="estilo/saque.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
    </head>

    <header>
         <nav class="menu">
                    <input type="checkbox" class="menu-faketrigger">
                    <div class="menu-lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li><a href="MenuPrincipal.php">inicio</a></li>
                        <li><a href="Deposito.php">depositar</a></li>
                        <li><a href="Investimento.php">Investir</a></li>
                        <li class="sacar"><a href="#">Sacar</a></li>
                        <li><a href="Transferir.php">Transferência de valores</a></li>
                        <li><a href="AtualizarConta.php">Atualizar Dados da conta</li></a>
                        <li><a href="AtualizarCliente.php">Atualizar Dados Pessoais</li></a>
                        <li><a href="Sair.php">Sair</a></li>
                    </ul>
            </nav>
            <h1>Menu Principal</h1>
    </header>

    <section>
        <?php

            /*Captura do valor */
            $valor = filter_input_array(INPUT_POST, FILTER_DEFAULT);
        
        ?>

        <form action="<?php $_SERVER['PHP_SELF']?>" method="post">

            <label for="valor"> Informe o valor do saque:</label><br>
            <input type="number" step="0.005" name="valor" class="input-form" required><br>
            <input type="submit" value="Sacar" class="botao">
        </form>

        <?php

            /*Antes de instanciar o objeto e chamar o metodo, vamos
            verificar se o campo do fomulário está preenchido */
            if(!empty($valor['valor'])){

                include 'Dados.php';

                $saque = new Dados();

                $saque->Saque($valor);
            }
        
        ?>
    </section>
</html>