



<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initail-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <link rel="stylesheet" href="estilo/cadastro.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
    </head>


    <body>

        <?php
        
            $dados_cliente = filter_input_array(INPUT_POST, FILTER_DEFAULT);

            $dados_conta = filter_input_array(INPUT_POST, FILTER_DEFAULT);

            $fotos = $_FILES['fotos']??null;
        
        ?>

        <section>
            <form action="<?php $_SERVER['PHP_SELF']?>" method="post" enctype="multipart/form-data">

                <label for="nome">Nome:</label>
                <input typr="text" name="nome" required class="input-form" autocomplete="off"><br>

                <label for="cpf">CPF:</label>
                <input type="text" name="cpf" required class="input-form" autocomplete="off"><br>

                <label for="email">Email:</label>
                <input type="text" name="email" class="input-form" required autocomplete="off"><br>

                <label for="ano_nascimento">ano(nasc):</label>
                <input type="text" name="ano_nascimento" class="input-form" required autocomplete="off"><br>

                <label for="senha">Senha:</label>
                <input type="text"  name="senha" required autocomplete="off" class="input-form"><br>

                <label for="fotos">Foto de perfil</label>
                <input type="file" name="fotos" autocomplete="off" class="input-file">

                <label for="numero_conta">Numero conta:</label>
                <input type="text" name="numero_conta" class="input-form" autocomplete="off" required><br>

                <label for="tipo">Tipo(CC ou CP):</label>
                <input type="text" name="tipo" class="input-form" autocomplete="off" required>

                <label for="saldo">Saldo</label>
                <input type="number" name="saldo" class="input-form"  step = "0.05" autocomplete="off" required><br>

                <input type="submit" value="Cadastrar Dados" class="botao"> 

                <p><a href="index.php">Voltar a tela de login</a></p>
            </form>

            <?php

                if(!empty($dados_cliente['nome']) && !empty($dados_cliente['cpf']) && !empty($dados_cliente['email']) && !empty($dados_cliente['ano_nascimento']) && !empty($dados_cliente['senha']) && !empty($dados_conta['numero_conta']) && !empty($dados_conta['tipo']) && !empty($dados_conta['saldo'])){

                    
                    include 'Dados.php';

                    $dados = new Dados();

                    $dados->cadastro($dados_cliente, $dados_conta, $fotos);
                }
            ?>
        </section>

    </body>
</html>


