

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
        <link rel="stylesheet" href="estilo/atualizarCliente.css">
        <title>Sistema Bancário</title>
    </head>

    <body>
         <header>
             <nav class="menu">
                    <input type="checkbox" class="menu-faketrigger">
                    <div class="menu-lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li><a href="MenuPrincipal.php">inicio</a></li>
                        <li><a href="Deposito.php">depositar</a></li>
                        <li><a href="Investimento.php">Investir</a></li>
                        <li><a href="Sacar.php">Sacar</a></li>
                        <li><a href="Transferir.php">Transferência de valores</a></li>
                        <li><a href="AtualizarConta.php">Atualizar Dados da conta</li></a>
                        <li class="atualizar_cliente"><a href="#">Atualizar Dados Pessoais</li></a>
                        <li><a href="Sair.php">Sair</a></li>
                    </ul>
            </nav>
            <h1>Menu Principal</h1>
         </header>

         <section>
            <?php
            
                $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

                $fotos = $_FILES['fotos']??null;
            ?>

            <form action="<?php $_SERVER['PHP_SELF']?>" method="post" enctype="multipart/form-data">
                <label for="nome">Novo Nome:</label><br>
                <input type="text" required name="nome"  class="input-form" autocomplete="off"><br>

                <label for="email">Novo Email</label><br>
                <input type="text" required name="email" class="input-form" autocomplete="off"><br>

                <label for="ano_nascimento">Novo ano de nascimento</label><br>
                <input type="text" required name="ano_nascimento" class="input-form" autocomplete="off"><br>

                <label for="fotos">Nova foto de perfil</label><br>
                <input type="file" required name="fotos" class="input-file" autocomplete="off"><br>

                <label for="senha">Nova Senha</label><br>
                <input type="text" required name="senha" class="input-form" autocomplete="off"><br>

                <input type="submit" value="atualizar dados" class="botao">
            </form>

            <?php
            
                if(!empty($dados)){

                    include 'Dados.php';

                    $atualizar_cliente = new Dados();

                    $atualizar_cliente->atualizarCliente($dados, $fotos);
                }
            ?>
         </section>
    </body>
</html>